package com.plintusvisuals.client.module.setting;

import java.awt.Color;

public class ColorSetting extends Setting<Color> {
    public ColorSetting(String name, Color defaultValue) {
        super(name, defaultValue);
    }

    public Color getColor() {
        return get();
    }
}
