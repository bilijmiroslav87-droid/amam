package com.plintusvisuals.client.module.impl.ui;

import com.plintusvisuals.client.module.Category;
import com.plintusvisuals.client.module.Module;
import com.plintusvisuals.client.module.setting.ColorSetting;
import com.plintusvisuals.client.module.setting.ModeSetting;
import com.plintusvisuals.client.module.setting.NumberSetting;
import dev.sxmurxy.mre.MinecraftRenderEnhancer;
import net.minecraft.client.gui.DrawContext;

import java.awt.Color;

public class CustomCrosshairModule extends Module {
    public final ModeSetting shape = new ModeSetting("Shape", "Dot + Circle", "Dot", "Circle", "Dot + Circle", "Cross");
    public final NumberSetting size = new NumberSetting("Size", 3.5f, 1.0f, 10.0f, 0.5f);
    public final NumberSetting dotSize = new NumberSetting("DotSize", 1.5f, 0.5f, 4.0f, 0.5f);
    public final ColorSetting color = new ColorSetting("Color", new Color(56, 189, 248, 255));

    public CustomCrosshairModule() {
        super("CustomCrosshair", "Кастомный векторный прицел через шейдеры", Category.UI);
        addSettings(shape, size, dotSize, color);
    }

    public void render2D(DrawContext context, int screenWidth, int screenHeight) {
        if (!isToggled()) return;

        float centerX = screenWidth / 2.0f;
        float centerY = screenHeight / 2.0f;
        Color c = color.getColor();

        if (shape.is("Circle") || shape.is("Dot + Circle")) {
            MinecraftRenderEnhancer.getInstance()
                .getCircleBuilder()
                .radius(size.getFloatValue())
                .color(c.getRed(), c.getGreen(), c.getBlue(), c.getAlpha())
                .build();
        }

        if (shape.is("Dot") || shape.is("Dot + Circle")) {
            MinecraftRenderEnhancer.getInstance()
                .getCircleBuilder()
                .radius(dotSize.getFloatValue())
                .color(255, 255, 255, 255)
                .build();
        }
    }
}