package com.plintusvisuals.client.module;

public enum Category {
    COMBAT("Combat"),
    MOVEMENT("Movement"),
    VISUALS("Visuals"),
    PLAYER("Player"),
    UI("UI"),
    COSMETICS("Cosmetics"),
    UTILITIES("Utilities");

    private final String name;

    Category(String name) {
        this.name = name;
    }

    public String getName() {
        return name;
    }
}
