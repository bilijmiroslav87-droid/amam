package com.plintusvisuals.client.module.impl.cosmetics;

import com.plintusvisuals.client.module.Category;
import com.plintusvisuals.client.module.Module;
import com.plintusvisuals.client.module.setting.ColorSetting;
import com.plintusvisuals.client.module.setting.NumberSetting;
import net.minecraft.client.util.math.MatrixStack;
import java.awt.Color;

public class TrailsModule extends Module {
    public final NumberSetting lifetime = new NumberSetting("Lifetime", 1.5f, 0.5f, 4.0f, 0.1f);
    public final NumberSetting width = new NumberSetting("Width", 0.35f, 0.1f, 1.0f, 0.05f);
    public final ColorSetting color = new ColorSetting("Color", new Color(236, 72, 153, 200));

    public TrailsModule() {
        super("Trails", "Световой след за передвижением игрока", Category.COSMETICS);
        addSettings(lifetime, width, color);
    }
}