package com.plintusvisuals.client.module.impl.combat;

import com.plintusvisuals.client.module.Category;
import com.plintusvisuals.client.module.Module;
import com.plintusvisuals.client.module.setting.BooleanSetting;
import com.plintusvisuals.client.module.setting.ModeSetting;
import com.plintusvisuals.client.util.NotificationManager;
import com.plintusvisuals.client.util.NotificationType;
import net.minecraft.client.MinecraftClient;
import net.minecraft.entity.Entity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.text.Text;

import java.util.HashMap;
import java.util.Map;

public class TotemPopCounterModule extends Module {
    public final BooleanSetting chatNotify = new BooleanSetting("ChatNotify", true);
    public final BooleanSetting visualPop = new BooleanSetting("VisualPop", true);
    public final ModeSetting sound = new ModeSetting("Sound", "Plintus High", "Plintus High", "Boom", "Bell", "None");

    private final Map<String, Integer> popCountMap = new HashMap<>();

    public TotemPopCounterModule() {
        super("TotemPopCounter", "Счетчик потраченных тотемов у врагов", Category.COMBAT);
        addSettings(chatNotify, visualPop, sound);
    }

    public void onTotemPop(Entity entity) {
        if (!isToggled() || !(entity instanceof PlayerEntity player)) return;
        if (player == MinecraftClient.getInstance().player) return;

        String name = player.getName().getString();
        int pops = popCountMap.getOrDefault(name, 0) + 1;
        popCountMap.put(name, pops);

        if (chatNotify.get()) {
            MinecraftClient.getInstance().inGameHud.getChatHud().addMessage(
                Text.literal("§7[§dPlintus§7] §fИгрок §b" + name + " §fпопнул §c" + pops + " §fтотем(ов)!")
            );
        }

        NotificationManager.add("Totem Pop", name + " попнул " + pops + " тотем!", NotificationType.WARNING);
    }

    public void onPlayerDeath(PlayerEntity player) {
        if (player == null) return;
        String name = player.getName().getString();
        if (popCountMap.containsKey(name)) {
            int total = popCountMap.remove(name);
            if (chatNotify.get()) {
                MinecraftClient.getInstance().inGameHud.getChatHud().addMessage(
                    Text.literal("§7[§dPlintus§7] §b" + name + " §aпогиб §fпосле §c" + total + " §fтотемов!")
                );
            }
        }
    }
}