package com.plintusvisuals.client.module.impl.visuals;

import com.plintusvisuals.client.module.Category;
import com.plintusvisuals.client.module.Module;
import com.plintusvisuals.client.module.setting.BooleanSetting;
import com.plintusvisuals.client.module.setting.ModeSetting;
import com.plintusvisuals.client.module.setting.NumberSetting;
import net.minecraft.entity.Entity;
import net.minecraft.util.Identifier;

public class HitParticlesModule extends Module {
    public final ModeSetting texture = new ModeSetting("Texture", "Heart", "Heart", "Dollar", "Star", "Genshin", "Rhombus");
    public final NumberSetting amount = new NumberSetting("Amount", 8.0f, 2.0f, 25.0f, 1.0f);
    public final BooleanSetting physics = new BooleanSetting("Physics", true);

    public HitParticlesModule() {
        super("HitParticles", "Кастомные партиклы Plintus при нанесении удара", Category.VISUALS);
        addSettings(texture, amount, physics);
    }

    public Identifier getParticleTexture() {
        String mode = texture.get();
        return switch (mode) {
            case "Dollar" -> Identifier.of("plintusvisuals", "textures/particles/dollar.png");
            case "Star" -> Identifier.of("plintusvisuals", "textures/particles/star.png");
            case "Genshin" -> Identifier.of("plintusvisuals", "textures/particles/genshin.png");
            case "Rhombus" -> Identifier.of("plintusvisuals", "textures/particles/rhombus.png");
            default -> Identifier.of("plintusvisuals", "textures/particles/heart.png");
        };
    }

    public void onAttackEntity(Entity target) {
        if (!isToggled() || target == null) return;
        // Спавн партиклов в точке удара target.getPos()
    }
}