package com.plintusvisuals.client.module.impl.combat;

import com.plintusvisuals.client.module.Category;
import com.plintusvisuals.client.module.Module;
import com.plintusvisuals.client.module.setting.ColorSetting;
import com.plintusvisuals.client.module.setting.ModeSetting;
import com.plintusvisuals.client.module.setting.NumberSetting;
import dev.sxmurxy.mre.MinecraftRenderEnhancer;
import net.minecraft.client.render.VertexConsumerProvider;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.entity.LivingEntity;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;
import org.joml.Vector4f;

import java.awt.Color;

/**
 * TargetESP Module for Plintus Visuals Fabric 1.21.4
 * Совместимо с Fold Craft Launcher и MRE Renderer
 */
public class TargetESPModule extends Module {
    public final ModeSetting mode = new ModeSetting("Mode", "Astolfo Circle", "Astolfo Circle", "MRE Stars", "Target PNG", "Jello Ring");
    public final NumberSetting radius = new NumberSetting("Radius", 0.9f, 0.3f, 2.5f, 0.1f);
    public final NumberSetting speed = new NumberSetting("Speed", 3.0f, 0.5f, 10.0f, 0.5f);
    public final ColorSetting color = new ColorSetting("Color", new Color(168, 85, 247, 255));

    public TargetESPModule() {
        super("TargetESP", "Подсветка атакуемой цели с использованием шейдеров MRE", Category.COMBAT);
        addSettings(mode, radius, speed, color);
    }

    public void render3D(MatrixStack matrices, LivingEntity target, float tickDelta) {
        if (!isToggled() || target == null || target.isDead()) return;

        Vec3d targetPos = target.getLerpedPos(tickDelta);
        double x = targetPos.x;
        double y = targetPos.y + (target.getHeight() / 2.0);
        double z = targetPos.z;

        float time = (System.currentTimeMillis() % 100000L) / 1000.0f * speed.getFloatValue();

        matrices.push();
        // Рендер кольца через рендерер MRE
        if (mode.is("Astolfo Circle")) {
            renderCircleShader(matrices, x, y, z, time, radius.getFloatValue());
        }
        matrices.pop();
    }

    private void renderCircleShader(MatrixStack matrices, double x, double y, double z, float time, float rad) {
        Color c = color.getColor();
        // Рендерер MRE sxmurxy
        MinecraftRenderEnhancer.getInstance()
            .getCircleBuilder()
            .radius(rad)
            .color(c.getRed(), c.getGreen(), c.getBlue(), c.getAlpha())
            .build();
    }
}