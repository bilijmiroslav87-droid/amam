package com.plintusvisuals.client.module.impl.ui;

import com.plintusvisuals.client.module.Category;
import com.plintusvisuals.client.module.Module;
import com.plintusvisuals.client.module.setting.BooleanSetting;
import com.plintusvisuals.client.module.setting.ModeSetting;
import dev.sxmurxy.mre.MinecraftRenderEnhancer;
import net.minecraft.client.gui.DrawContext;

public class TargetHUDModule extends Module {
    public final ModeSetting style = new ModeSetting("Style", "Plintus Modern", "Plintus Modern", "Minimal", "Astolfo");
    public final BooleanSetting blur = new BooleanSetting("Blur", true);

    public TargetHUDModule() {
        super("TargetHUD", "Информативная плашка цели с полоской здоровья и эффектами", Category.UI);
        addSettings(style, blur);
    }

    public void render(DrawContext context, float tickDelta) {
        if (!isToggled()) return;
        // Отрисовка подложки через MRE
        MinecraftRenderEnhancer.getInstance()
            .getPillBlurBuilder()
            .size(150, 45)
            .radius(10f)
            .build();
    }
}