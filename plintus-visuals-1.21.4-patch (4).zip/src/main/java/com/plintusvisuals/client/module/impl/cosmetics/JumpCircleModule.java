package com.plintusvisuals.client.module.impl.cosmetics;

import com.plintusvisuals.client.module.Category;
import com.plintusvisuals.client.module.Module;
import com.plintusvisuals.client.module.setting.ColorSetting;
import com.plintusvisuals.client.module.setting.NumberSetting;
import java.awt.Color;

public class JumpCircleModule extends Module {
    public final NumberSetting speed = new NumberSetting("Speed", 1.0f, 0.2f, 3.0f, 0.1f);
    public final NumberSetting maxRadius = new NumberSetting("MaxRadius", 2.0f, 0.5f, 4.0f, 0.2f);
    public final ColorSetting color = new ColorSetting("Color", new Color(168, 85, 247, 220));

    public JumpCircleModule() {
        super("JumpCircle", "Анимированные расходящиеся круги при прыжке", Category.COSMETICS);
        addSettings(speed, maxRadius, color);
    }
}