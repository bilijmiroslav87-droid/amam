package com.plintusvisuals.client.module;

import com.plintusvisuals.client.module.Category;
import com.plintusvisuals.client.module.Module;
import com.plintusvisuals.client.module.impl.combat.TargetESPModule;
import com.plintusvisuals.client.module.impl.cosmetics.ChinaHatModule;
import com.plintusvisuals.client.module.impl.visuals.BlockOverlayModule;
import com.plintusvisuals.client.module.impl.combat.TotemPopCounterModule;
import com.plintusvisuals.client.module.impl.ui.CustomCrosshairModule;
import com.plintusvisuals.client.module.impl.cosmetics.TrailsModule;
import com.plintusvisuals.client.module.impl.cosmetics.JumpCircleModule;
import com.plintusvisuals.client.module.impl.ui.TargetHUDModule;
import com.plintusvisuals.client.module.impl.visuals.TracersModule;
import com.plintusvisuals.client.module.impl.visuals.HitParticlesModule;
import com.plintusvisuals.client.module.impl.visuals.CustomFogModule;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class ModuleManager {
    private static final List<Module> modules = new ArrayList<>();

    public static void init() {
        modules.clear();

        add(new TargetESPModule());
        add(new ChinaHatModule());
        add(new BlockOverlayModule());
        add(new TotemPopCounterModule());
        add(new CustomCrosshairModule());
        add(new TrailsModule());
        add(new JumpCircleModule());
        add(new TargetHUDModule());
        add(new TracersModule());
        add(new HitParticlesModule());
        add(new CustomFogModule());
    }

    public static void add(Module module) {
        modules.add(module);
    }

    public static List<Module> getModules() {
        return Collections.unmodifiableList(modules);
    }

    public static List<Module> getByCategory(Category category) {
        List<Module> list = new ArrayList<>();
        for (Module m : modules) {
            if (m.getCategory() == category) {
                list.add(m);
            }
        }
        return list;
    }

    @SuppressWarnings("unchecked")
    public static <T extends Module> T getByClass(Class<T> clazz) {
        for (Module m : modules) {
            if (m.getClass() == clazz) {
                return (T) m;
            }
        }
        return null;
    }

    public static Module getByName(String name) {
        for (Module m : modules) {
            if (m.getName().equalsIgnoreCase(name)) {
                return m;
            }
        }
        return null;
    }
}
