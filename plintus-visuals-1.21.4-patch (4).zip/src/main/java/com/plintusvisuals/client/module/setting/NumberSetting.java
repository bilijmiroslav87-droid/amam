package com.plintusvisuals.client.module.setting;

public class NumberSetting extends Setting<Double> {
    private final double min;
    private final double max;
    private final double step;

    public NumberSetting(String name, float defaultValue, float min, float max, float step) {
        super(name, (double) defaultValue);
        this.min = min;
        this.max = max;
        this.step = step;
    }

    public NumberSetting(String name, double defaultValue, double min, double max, double step) {
        super(name, defaultValue);
        this.min = min;
        this.max = max;
        this.step = step;
    }

    public double getMin() { return min; }
    public double getMax() { return max; }
    public double getStep() { return step; }
    public float getFloatValue() { return getValue().floatValue(); }
    public int getIntValue() { return (int) Math.round(getValue()); }
}
