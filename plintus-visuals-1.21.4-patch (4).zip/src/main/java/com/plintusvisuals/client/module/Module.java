package com.plintusvisuals.client.module;

import com.plintusvisuals.client.module.setting.Setting;
import java.util.ArrayList;
import java.util.List;

public abstract class Module {
    private final String name;
    private final String description;
    private final Category category;
    private boolean toggled;
    private final List<Setting<?>> settings = new ArrayList<>();

    public Module(String name, String description, Category category) {
        this.name = name;
        this.description = description;
        this.category = category;
        this.toggled = false;
    }

    public void addSettings(Setting<?>... settings) {
        for (Setting<?> s : settings) {
            this.settings.add(s);
        }
    }

    public void toggle() {
        setToggled(!toggled);
    }

    public void setToggled(boolean toggled) {
        this.toggled = toggled;
        if (toggled) {
            onEnable();
        } else {
            onDisable();
        }
    }

    public boolean isToggled() {
        return toggled;
    }

    public String getName() {
        return name;
    }

    public String getDescription() {
        return description;
    }

    public Category getCategory() {
        return category;
    }

    public List<Setting<?>> getSettings() {
        return settings;
    }

    public void onEnable() {}
    public void onDisable() {}
}
