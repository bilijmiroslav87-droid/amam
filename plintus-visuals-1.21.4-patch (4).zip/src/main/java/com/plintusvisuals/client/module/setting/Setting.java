package com.plintusvisuals.client.module.setting;

public abstract class Setting<T> {
    private final String name;
    private T value;

    public Setting(String name, T defaultValue) {
        this.name = name;
        this.value = defaultValue;
    }

    public String getName() { return name; }
    public T get() { return value; }
    public T getValue() { return value; }
    public void set(T value) { this.value = value; }
}
