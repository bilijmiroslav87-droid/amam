package com.plintusvisuals.client.util;

public enum NotificationType {
    INFO,
    WARNING,
    SUCCESS,
    ERROR
}
