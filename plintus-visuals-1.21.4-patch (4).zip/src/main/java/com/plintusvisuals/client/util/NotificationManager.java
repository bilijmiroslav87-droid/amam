package com.plintusvisuals.client.util;

public class NotificationManager {
    public static void add(String title, String message, NotificationType type) {
        // Notification log
    }
}
