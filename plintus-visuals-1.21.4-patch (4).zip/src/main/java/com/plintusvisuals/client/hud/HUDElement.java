package com.plintusvisuals.client.hud;

import net.minecraft.client.gui.DrawContext;

public abstract class HUDElement {
    private final String name;
    private int width;
    private int height;

    public HUDElement(String name, int width, int height) {
        this.name = name;
        this.width = width;
        this.height = height;
    }

    public String getName() { return name; }
    public int getWidth() { return width; }
    public int getHeight() { return height; }

    public abstract void render(DrawContext context, float tickDelta);
}
