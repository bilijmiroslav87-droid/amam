package com.plintusvisuals.client.hud.elements;

import com.plintusvisuals.client.hud.HUDElement;
import dev.sxmurxy.mre.MinecraftRenderEnhancer;
import net.minecraft.client.gui.DrawContext;

public class TargetHUDElement extends HUDElement {
    public TargetHUDElement() {
        super("TargetHUD", 150, 45);
    }

    @Override
    public void render(DrawContext context, float tickDelta) {
        MinecraftRenderEnhancer.getInstance()
            .getPillBlurBuilder()
            .size(getWidth(), getHeight())
            .radius(10f)
            .build();
    }
}
