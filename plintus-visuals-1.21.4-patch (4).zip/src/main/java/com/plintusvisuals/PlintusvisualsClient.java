package com.plintusvisuals;

import com.plintusvisuals.client.module.ModuleManager;
import net.fabricmc.api.ClientModInitializer;

public class PlintusvisualsClient implements ClientModInitializer {
    @Override
    public void onInitializeClient() {
        ModuleManager.init();
    }
}
