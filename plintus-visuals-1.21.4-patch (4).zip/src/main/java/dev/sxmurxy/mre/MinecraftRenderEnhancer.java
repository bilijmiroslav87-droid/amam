package dev.sxmurxy.mre;

public class MinecraftRenderEnhancer {
    private static final MinecraftRenderEnhancer INSTANCE = new MinecraftRenderEnhancer();

    public static MinecraftRenderEnhancer getInstance() {
        return INSTANCE;
    }

    public CircleBuilder getCircleBuilder() {
        return new CircleBuilder();
    }

    public PillBlurBuilder getPillBlurBuilder() {
        return new PillBlurBuilder();
    }

    public Box3DBuilder getBox3DBuilder() {
        return new Box3DBuilder();
    }

    public static class CircleBuilder {
        public CircleBuilder radius(float r) { return this; }
        public CircleBuilder color(int r, int g, int b, int a) { return this; }
        public void build() {}
    }

    public static class PillBlurBuilder {
        public PillBlurBuilder size(float w, float h) { return this; }
        public PillBlurBuilder radius(float r) { return this; }
        public void build() {}
    }

    public static class Box3DBuilder {
        public Box3DBuilder box(net.minecraft.util.math.Box box) { return this; }
        public Box3DBuilder color(int r, int g, int b, int a) { return this; }
        public void build() {}
    }
}
